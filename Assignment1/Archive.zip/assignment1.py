import os
import math
import scipy.optimize
import numpy as np
import string
import random
import gzip

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from collections import defaultdict
from sklearn import linear_model
from utils import *

prefix = "../datasets/assignment1/" # Change this to wherever you put the dataset

def predictRating():
  allRatings = []
  userRatings = defaultdict(list)

  for user,book,r in readCSV(f"{prefix}train_Interactions.csv.gz"):
    allRatings.append((user,book,r))
    userRatings[user].append(r)

  ratingsTrain = allRatings[:190000]
  ratingsValid = allRatings[190000:]
  ratingsPerUser = defaultdict(list)
  ratingsPerItem = defaultdict(list)
  for u,b,r in ratingsTrain:
      ratingsPerUser[u].append((b,r))
      ratingsPerItem[b].append((u,r))

  trainRatings = [r[2] for r in ratingsTrain]
  globalAverage = getGlobalAverage(trainRatings)

  userAverage = {}
  for u in userRatings:
    userAverage[u] = sum(userRatings[u]) / len(userRatings[u])

  betaU = {}
  betaI = {}
  for u in ratingsPerUser:
      betaU[u] = 0

  for b in ratingsPerItem:
      betaI[b] = 0

  alpha = globalAverage # Could initialize anywhere, this is a guess
  alpha, betaU, betaI = goodModel(ratingsTrain, ratingsPerUser, ratingsPerItem, alpha, betaU, betaI, ratingsValid)

  # Removing previous file
  if os.path.exists("predictions_Rating.csv"):
     os.remove("predictions_Rating.csv")
  predictions = open("predictions_Rating.csv", 'w')
  for l in open(f"{prefix}pairs_Rating.csv"):
    if l.startswith("userID"):
      #header
      predictions.write(l)
      continue
    u,b = l.strip().split(',')
    if u in betaU and b in betaI:
      pred = alpha + betaU[u] + betaI[b]
      if pred < 0: pred = 0
      if pred > 5: pred = 5
      predictions.write(u + ',' + b + ',' + str(pred) + '\n')
    else:
      if u in userAverage:
        predictions.write(u + ',' + b + ',' + str(userAverage[u]) + '\n')
      else:
        predictions.write(u + ',' + b + ',' + str(globalAverage) + '\n')

  predictions.close()

### Would-read baseline: just rank which books are popular and which are not, and return '1' if a book is among the top-ranked

def predictRead():
  allRatings = []
  userRatings = defaultdict(list)

  for user,book,r in readCSV(f"{prefix}train_Interactions.csv.gz"):
    allRatings.append((user,book,r))
    userRatings[user].append(r)

  train_split = 0.9
  ratingsTrain = allRatings[:int(train_split * len(allRatings))]
  ratingsValid = allRatings[int(train_split * len(allRatings)):]
  
  ratingsPerUser = defaultdict(list)
  ratingsPerItem = defaultdict(list)
  for u,b,r in ratingsTrain:
      ratingsPerUser[u].append((b,r))
      ratingsPerItem[b].append((u,r))

  bookCount = defaultdict(int)
  totalRead = 0

  for user,book,_ in readCSV(f"{prefix}train_Interactions.csv.gz"):
    bookCount[book] += 1
    totalRead += 1

  mostPopular = [(bookCount[x], x) for x in bookCount]
  mostPopular.sort()
  mostPopular.reverse()

  # 50-50 split of validation set into read and not-read
  readValid, notReadValid = generateValidation(allRatings, ratingsValid)
  assert len(readValid) == len(notReadValid)
  print(f"Validation set: {len(readValid)} reads and {len(notReadValid)} not-reads")

  # Improved strategy
  return1 = improvedStrategy(mostPopular, totalRead)
  acc = evaluateStrategy(return1, readValid, notReadValid)
  print(f"Improved strategy accuracy: {acc}")
  
  # Removing previous file
  if os.path.exists("predictions_Read.csv"):
     os.remove("predictions_Read.csv")
  
  predictions = open("predictions_Read.csv", 'w')
  
  for l in open(f"{prefix}pairs_Read.csv"):
    if l.startswith("userID"):
      #header
      predictions.write(l)
      continue
    u,b = l.strip().split(',')

    # pred = jaccardThresh(u, b, ratingsPerItem, ratingsPerUser)
    # predictions.write(u + ',' + b + f",{pred}\n")
    # Predict '1' if book is in the return1 set
    if b in return1:
      predictions.write(u + ',' + b + f",1\n")
    else:
      predictions.write(u + ',' + b + f",0\n")

  predictions.close()

### Category prediction: look for keywords in the review text
def predictCat():
  data = []

  for d in readGz(f"{prefix}train_Category.json.gz"):
      data.append(d)
      
  # # Build vocab only once from training data
  # words, wordId, wordSet = buildVocab(data, NW=2000)

  # # Use same mapping for both train and test
  # X = betterFeatures(data, words, wordId, wordSet)
  # Xtrain = X[:9*len(X)//10]
  # Xvalid = X[9*len(X)//10:]

  # y = [d['genreID'] for d in data]
  # ytrain = y[:9*len(y)//10]
  # yvalid = y[9*len(y)//10:]

  
  # tfidf = TfidfVectorizer(
  #       lowercase=True,
  #       stop_words='english',
  #       max_features=20000,
  #       ngram_range=(1,2)
  #   )
  tfidf = TfidfVectorizer(
    lowercase=True,
    stop_words='english',
    max_features=20000,
    analyzer='char_wb',      # word-boundary char-grams
    ngram_range=(3, 5)       # 3–5 character windows
  )

  # Fit only on training data to avoid leakage
  corpus_train = [d['review_text'] for d in data]
  X_all = tfidf.fit_transform(corpus_train)
  y_all = np.array([d['genreID'] for d in data])

  # Split into train/valid
  Xtrain, Xvalid, ytrain, yvalid = train_test_split(
      X_all, y_all, test_size=0.1, random_state=42, shuffle=True
  )

  data_test = list(readGz(f"{prefix}test_Category.json.gz"))
  # Xtest = betterFeatures(data_test, words, wordId, wordSet)
  corpus_test = [d['review_text'] for d in data_test]
  Xtest = tfidf.transform(corpus_test)

  print(f"TF-IDF built with {len(tfidf.vocabulary_)} features.")

  mod = linear_model.LogisticRegression(
        C=20, penalty='l2', solver='liblinear', max_iter=2000
    )
  mod.fit(Xtrain, ytrain)

  pred_valid = mod.predict(Xvalid)
  correctB = yvalid == pred_valid
  correctB = sum(correctB) / len(correctB)
  print(f"Validation accuracy: {correctB}")

  pred_test = mod.predict(Xtest)

  # Removing previous file
  if os.path.exists("predictions_Category.csv"):
      os.remove("predictions_Category.csv")
  predictions = open("predictions_Category.csv", 'w')
  predictions.write("userID,reviewID,prediction\n")

  for ind, l in enumerate(readGz(f"{prefix}test_Category.json.gz")):
    predictions.write(l['user_id'] + ',' + l['review_id'] + "," + str(pred_test[ind]) + "\n")
  predictions.close()


if __name__ == "__main__":
  # predictRating()
  # predictRead()
  predictCat()